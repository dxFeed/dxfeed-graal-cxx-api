var structdxfcpp_1_1_lasting_event =
[
    [ "Ptr", "dd/d02/structdxfcpp_1_1_lasting_event.html#ab4051729b3cceb2ff31987680071241e", null ]
];