var structdxfcpp_1_1_event_type_with_symbol =
[
    [ "Ptr", "d7/d02/structdxfcpp_1_1_event_type_with_symbol.html#af4c0836555a45f8303b76f7efdaa49bf", null ],
    [ "getEventSymbol", "d7/d02/structdxfcpp_1_1_event_type_with_symbol.html#ae00c099cebda639adbecad51c2ff182b", null ],
    [ "setEventSymbol", "d7/d02/structdxfcpp_1_1_event_type_with_symbol.html#a2dc47763bdaf6bf5a33d68b4fd8b34ba", null ]
];