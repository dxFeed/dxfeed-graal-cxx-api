var structdxfcpp_1_1_c_entry_point_errors =
[
    [ "getCode", "d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#a2f0281effe38d5901cadc750aef8cacd", null ],
    [ "getDescription", "d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#adc73b1177b9d3d10545e9b14d55898c9", null ]
];