var dir_d44c64559bbebec7f509842c48db8b23 =
[
    [ "dxfeed_graal_c_api", "dir_95b33955a2bcc277b665023b28120c35.html", "dir_95b33955a2bcc277b665023b28120c35" ],
    [ "dxfeed_graal_cpp_api", "dir_9ff24b02f11fdfd0ef1fb378571854f7.html", "dir_9ff24b02f11fdfd0ef1fb378571854f7" ]
];