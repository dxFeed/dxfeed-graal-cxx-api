var searchData=
[
  ['not_5fconnected_0',['NOT_CONNECTED',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#af82eb2c48281dedb4d2a1994f07a22c6ad91be9b5ceb9fe0af02b9b02413eccf8',1,'dxfcpp::DXEndpoint']]]
];
