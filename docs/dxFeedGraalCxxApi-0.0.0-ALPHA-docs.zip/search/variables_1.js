var searchData=
[
  ['buy_0',['BUY',['../d7/d03/structdxfcpp_1_1_side.html#ab0a0ec12ea96aabd9f14612dac189fa0',1,'dxfcpp::Side']]]
];
