var searchData=
[
  ['withname_0',['withName',['../d9/d02/classdxfcpp_1_1_d_x_endpoint_1_1_builder.html#ab4eba04d0142dcd63d24fe7a1d3cae5a',1,'dxfcpp::DXEndpoint::Builder']]],
  ['withproperties_1',['withProperties',['../d9/d02/classdxfcpp_1_1_d_x_endpoint_1_1_builder.html#a73a17565b146393ae7a7d4ff39a1301f',1,'dxfcpp::DXEndpoint::Builder']]],
  ['withproperty_2',['withProperty',['../d9/d02/classdxfcpp_1_1_d_x_endpoint_1_1_builder.html#a06466a9c8a88df62c32c20e17788f4a4',1,'dxfcpp::DXEndpoint::Builder']]],
  ['withrole_3',['withRole',['../d9/d02/classdxfcpp_1_1_d_x_endpoint_1_1_builder.html#a78a4d67260b04c965ed28419637066a9',1,'dxfcpp::DXEndpoint::Builder']]]
];
