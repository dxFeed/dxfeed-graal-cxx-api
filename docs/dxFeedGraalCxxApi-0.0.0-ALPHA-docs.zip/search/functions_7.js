var searchData=
[
  ['id_0',['id',['../d2/d01/classdxfcpp_1_1_indexed_event_source.html#a9509f730a2a5e10aa2d14e14c3c0c9c2',1,'dxfcpp::IndexedEventSource']]],
  ['in_1',['in',['../de/d03/classdxfcpp_1_1_event_flag.html#a4317562bfdcc3856bd73ec792b32b46c',1,'dxfcpp::EventFlag::in(std::uint32_t eventFlagsMask) const'],['../de/d03/classdxfcpp_1_1_event_flag.html#aa757d1f18ee9e4f65e31d80d020daf68',1,'dxfcpp::EventFlag::in(const EventFlagsMask &amp;eventFlagsMask) const']]],
  ['indexedeventsource_2',['IndexedEventSource',['../d2/d01/classdxfcpp_1_1_indexed_event_source.html#a805ef1f6a08e9b8a8873e0880b0037b1',1,'dxfcpp::IndexedEventSource']]],
  ['is_3',['is',['../db/d03/structdxfcpp_1_1_shared_entity.html#ac83e17b089df3399f9a2216000ee859e',1,'dxfcpp::SharedEntity']]],
  ['iscancel_4',['isCancel',['../d3/d00/classdxfcpp_1_1_time_and_sale.html#ac7565bfe4ca6f2e143311a34381ffb65',1,'dxfcpp::TimeAndSale::isCancel()'],['../de/d02/classdxfcpp_1_1_option_sale.html#aab02b8f20bd89ce5e853e7b9f01795d4',1,'dxfcpp::OptionSale::isCancel()']]],
  ['isclosed_5',['isClosed',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a8513eebf380d198002fc62b142f251cf',1,'dxfcpp::DXEndpoint::isClosed()'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#aad81c2c90cffd1c3dfe6f51eb2d3337c',1,'dxfcpp::DXFeedSubscription::isClosed()']]],
  ['iscorrection_6',['isCorrection',['../d3/d00/classdxfcpp_1_1_time_and_sale.html#a0cea50fc81ebc97e25f87b9fbd2937d4',1,'dxfcpp::TimeAndSale::isCorrection()'],['../de/d02/classdxfcpp_1_1_option_sale.html#aaddaa4a45e4ab4457c02920c2ba42a08',1,'dxfcpp::OptionSale::isCorrection()']]],
  ['isextendedtradinghours_7',['isExtendedTradingHours',['../dd/d02/classdxfcpp_1_1_trade_base.html#acbdb37c7e5a24c5d686d699b7280a9a6',1,'dxfcpp::TradeBase::isExtendedTradingHours()'],['../d3/d00/classdxfcpp_1_1_time_and_sale.html#a918d0ca26279d5f5454195e8a37a4fd8',1,'dxfcpp::TimeAndSale::isExtendedTradingHours()'],['../de/d02/classdxfcpp_1_1_option_sale.html#a6d6a0032643c729fb148be5eec95ec99',1,'dxfcpp::OptionSale::isExtendedTradingHours()']]],
  ['isindexed_8',['isIndexed',['../d9/d00/classdxfcpp_1_1_event_type_enum.html#a0e7e834c2fa0cf74208906f4a572930b',1,'dxfcpp::EventTypeEnum']]],
  ['islasting_9',['isLasting',['../d9/d00/classdxfcpp_1_1_event_type_enum.html#a9a8e0beb2ba8334ceea4c691f8fd0f84',1,'dxfcpp::EventTypeEnum']]],
  ['isnew_10',['isNew',['../d3/d00/classdxfcpp_1_1_time_and_sale.html#a2e6ba609a4098c7db90463c02da19690',1,'dxfcpp::TimeAndSale::isNew()'],['../de/d02/classdxfcpp_1_1_option_sale.html#a35f06093c59f6e06788209edd6f55215',1,'dxfcpp::OptionSale::isNew()']]],
  ['isonlyindexed_11',['isOnlyIndexed',['../d9/d00/classdxfcpp_1_1_event_type_enum.html#a0da22bded800f8802acaae16edec8e5f',1,'dxfcpp::EventTypeEnum']]],
  ['isshortsalerestricted_12',['isShortSaleRestricted',['../db/d00/classdxfcpp_1_1_profile.html#a2c60eda8d9d0f96661920dc7c9b511c8',1,'dxfcpp::Profile']]],
  ['isspreadleg_13',['isSpreadLeg',['../d3/d00/classdxfcpp_1_1_time_and_sale.html#abffbd9411be7a74df74b56b9c48e6925',1,'dxfcpp::TimeAndSale::isSpreadLeg()'],['../de/d02/classdxfcpp_1_1_option_sale.html#aed068e896c22c3440476365c8639e429',1,'dxfcpp::OptionSale::isSpreadLeg()']]],
  ['isstringsymbol_14',['isStringSymbol',['../db/d03/structdxfcpp_1_1_symbol_wrapper.html#a0f66038aa88942094d6a34838e3bafa4',1,'dxfcpp::SymbolWrapper']]],
  ['istimeseries_15',['isTimeSeries',['../d9/d00/classdxfcpp_1_1_event_type_enum.html#adb2e3e73523a4ac256e48a64cfa6c06d',1,'dxfcpp::EventTypeEnum']]],
  ['istradinghalted_16',['isTradingHalted',['../db/d00/classdxfcpp_1_1_profile.html#ae1e964004f1d444d92e6cbc11ec9e1da',1,'dxfcpp::Profile']]],
  ['isvalidtick_17',['isValidTick',['../d3/d00/classdxfcpp_1_1_time_and_sale.html#a6d467ad534d4e846e61f011b66bbda72',1,'dxfcpp::TimeAndSale::isValidTick()'],['../de/d02/classdxfcpp_1_1_option_sale.html#a30c4f60e40574532407e8149b953e85f',1,'dxfcpp::OptionSale::isValidTick()']]],
  ['iswildcardsymbol_18',['isWildcardSymbol',['../db/d03/structdxfcpp_1_1_symbol_wrapper.html#a8f39830e71468fb50a80b5a56750db42',1,'dxfcpp::SymbolWrapper']]]
];
