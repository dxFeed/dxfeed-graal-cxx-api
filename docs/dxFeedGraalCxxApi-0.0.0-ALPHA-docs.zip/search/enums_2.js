var searchData=
[
  ['state_0',['State',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#af82eb2c48281dedb4d2a1994f07a22c6',1,'dxfcpp::DXEndpoint']]]
];
