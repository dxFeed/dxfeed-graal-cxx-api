var searchData=
[
  ['cancel_0',['CANCEL',['../dd/d00/structdxfcpp_1_1_time_and_sale_type.html#ac1fe63bfd6b7ecd97aaf84a30fffca20',1,'dxfcpp::TimeAndSaleType']]],
  ['correction_1',['CORRECTION',['../dd/d00/structdxfcpp_1_1_time_and_sale_type.html#a7e2c0901dc3dd99de9dc03dc3e56e933',1,'dxfcpp::TimeAndSaleType']]],
  ['cpu_5ffeature_5fcheck_5ffailed_2',['CPU_FEATURE_CHECK_FAILED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#abb1021d4b2abd795435253c890beb2cd',1,'dxfcpp::CEntryPointErrors']]]
];
