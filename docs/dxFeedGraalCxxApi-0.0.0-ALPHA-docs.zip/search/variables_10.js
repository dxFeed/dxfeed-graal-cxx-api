var searchData=
[
  ['unattached_5fthread_0',['UNATTACHED_THREAD',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#a73fef068db152a57799f076b4f8d7cb3',1,'dxfcpp::CEntryPointErrors']]],
  ['uncaught_5fexception_1',['UNCAUGHT_EXCEPTION',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#ac3e9e07f0359860762bc5ff96c52a270',1,'dxfcpp::CEntryPointErrors']]],
  ['undefined_2',['UNDEFINED',['../dc/d03/structdxfcpp_1_1_direction.html#a28ed1ad22def1af115558b95d2743ed5',1,'dxfcpp::Direction::UNDEFINED'],['../da/d02/structdxfcpp_1_1_short_sale_restriction.html#a89d854a50c0d747621bbf7d436ee8e44',1,'dxfcpp::ShortSaleRestriction::UNDEFINED'],['../d9/d02/structdxfcpp_1_1_trading_status.html#a5b3c0b4878efb41c71be687478938ed8',1,'dxfcpp::TradingStatus::UNDEFINED'],['../d7/d03/structdxfcpp_1_1_side.html#a3f204205ee6bb9e364a7e482c0716f67',1,'dxfcpp::Side::UNDEFINED']]],
  ['uninitialized_5fisolate_3',['UNINITIALIZED_ISOLATE',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#af8932884e26b6fc56cf5a5231b0b142c',1,'dxfcpp::CEntryPointErrors']]],
  ['unspecified_4',['UNSPECIFIED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#a64426a10151f32b6c708c1dca6265152',1,'dxfcpp::CEntryPointErrors']]],
  ['unsupported_5fisolate_5fparameters_5fversion_5',['UNSUPPORTED_ISOLATE_PARAMETERS_VERSION',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#ae0016a8ba5ce623fafcab1863ae78841',1,'dxfcpp::CEntryPointErrors']]],
  ['up_6',['UP',['../dc/d03/structdxfcpp_1_1_direction.html#aad4a9d806115c0698221f57eabfbc04b',1,'dxfcpp::Direction']]]
];
