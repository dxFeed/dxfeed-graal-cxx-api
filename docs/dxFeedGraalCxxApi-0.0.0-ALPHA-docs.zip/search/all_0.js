var searchData=
[
  ['active_0',['ACTIVE',['../da/d02/structdxfcpp_1_1_short_sale_restriction.html#a9aaad37646ab7ea16488735538d1a927',1,'dxfcpp::ShortSaleRestriction::ACTIVE'],['../d9/d02/structdxfcpp_1_1_trading_status.html#ab779651641bb7685ca24bf62848fe1d8',1,'dxfcpp::TradingStatus::ACTIVE']]],
  ['add_1',['add',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#a845abea0f4f416a3f33130153edf9f7e',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['addeventlistener_2',['addEventListener',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a3cbf630dbc54ce3be50412392102f993',1,'dxfcpp::DXFeedSubscription::addEventListener(EventListener &amp;&amp;listener) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a5d47c3bf1b10e850ea9291522602d7dd',1,'dxfcpp::DXFeedSubscription::addEventListener(std::function&lt; void(const std::vector&lt; std::shared_ptr&lt; EventT &gt; &gt; &amp;)&gt; &amp;&amp;listener) noexcept']]],
  ['addlowpriority_3',['addLowPriority',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#a92d291de6b5347bc519ceb457a797462',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['addstatechangelistener_4',['addStateChangeListener',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a619cb80fb1de10040705be2ce9a20068',1,'dxfcpp::DXEndpoint']]],
  ['addsymbols_5',['addSymbols',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a82f6161c934193091349eacbcf368d26',1,'dxfcpp::DXFeedSubscription::addSymbols(const SymbolWrapper &amp;symbolWrapper) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a1a729f7d17b344447bd15757ffc12a98',1,'dxfcpp::DXFeedSubscription::addSymbols(SymbolIt begin, SymbolIt end) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a8200b1eb47a022ac2c2d64584b61699f',1,'dxfcpp::DXFeedSubscription::addSymbols(const SymbolsCollection &amp;collection) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a20c328d64bbd6ce84210a1394433a8f2',1,'dxfcpp::DXFeedSubscription::addSymbols(std::initializer_list&lt; SymbolWrapper &gt; collection) noexcept']]],
  ['api_2eh_6',['api.h',['../dc/d01/api_8h.html',1,'']]],
  ['argument_5fparsing_5ffailed_7',['ARGUMENT_PARSING_FAILED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#a5480767c2f85a4fbac6a2497e9b74654',1,'dxfcpp::CEntryPointErrors']]],
  ['asstringsymbol_8',['asStringSymbol',['../db/d03/structdxfcpp_1_1_symbol_wrapper.html#a9ed87465e80386fc45dcd1ffc3c5b6a6',1,'dxfcpp::SymbolWrapper']]],
  ['aswildcardsymbol_9',['asWildcardSymbol',['../db/d03/structdxfcpp_1_1_symbol_wrapper.html#a8fc8e32454a3c5b4a27271ab719ed571',1,'dxfcpp::SymbolWrapper']]],
  ['attach_10',['attach',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#ab022c88abb0ac4c2090da5e85bdebd34',1,'dxfcpp::DXFeedSubscription']]],
  ['aux_5fimage_5fprimary_5fimage_5fmismatch_11',['AUX_IMAGE_PRIMARY_IMAGE_MISMATCH',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#a90fbb14ae1ef9525157809538c0b12f0',1,'dxfcpp::CEntryPointErrors']]],
  ['aux_5fimage_5funsupported_12',['AUX_IMAGE_UNSUPPORTED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#a59ee692e38cf4d93d3eec5ee6e2c33b9',1,'dxfcpp::CEntryPointErrors']]],
  ['awaitnotconnected_13',['awaitNotConnected',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a82ec4a2efd7f8c976cd3874a31aaacb8',1,'dxfcpp::DXEndpoint']]],
  ['awaitprocessed_14',['awaitProcessed',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a1facf9c56758e1dee75b278d9271ef62',1,'dxfcpp::DXEndpoint']]]
];
