var searchData=
[
  ['underlying_0',['Underlying',['../db/d02/classdxfcpp_1_1_underlying.html#a18d8a57aa869b731346c648d73c50f5f',1,'dxfcpp::Underlying::Underlying() noexcept=default'],['../db/d02/classdxfcpp_1_1_underlying.html#a5445fdf7d6f394272ce151f32785eb1f',1,'dxfcpp::Underlying::Underlying(std::string eventSymbol) noexcept']]],
  ['user_1',['user',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a6d1ed418821c52412fa9b5153c1db4a5',1,'dxfcpp::DXEndpoint']]]
];
