var searchData=
[
  ['cancel_0',['CANCEL',['../dd/d00/structdxfcpp_1_1_time_and_sale_type.html#ac1fe63bfd6b7ecd97aaf84a30fffca20',1,'dxfcpp::TimeAndSaleType']]],
  ['centrypointerrors_1',['CEntryPointErrors',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html',1,'dxfcpp']]],
  ['clear_2',['clear',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a887783cf364e0c2e95e20ea2376be8ba',1,'dxfcpp::DXFeedSubscription']]],
  ['close_3',['close',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a06b70688f7aa279e0a905099cb7cb4c9',1,'dxfcpp::DXEndpoint::close()'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a3843aa7e4d0eefddbcdc695909566c45',1,'dxfcpp::DXFeedSubscription::close()']]],
  ['closeandawaittermination_4',['closeAndAwaitTermination',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a80ef90ad7bf0e92968c4379a53d90ea5',1,'dxfcpp::DXEndpoint']]],
  ['closed_5',['CLOSED',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#af82eb2c48281dedb4d2a1994f07a22c6a110ccf2f5d2ff4eda1fd1a494293467d',1,'dxfcpp::DXEndpoint']]],
  ['connect_6',['connect',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a26dc7548a792c0e3eb0b47a90ff7771c',1,'dxfcpp::DXEndpoint']]],
  ['connected_7',['CONNECTED',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#af82eb2c48281dedb4d2a1994f07a22c6aa5afd6edd5336d91316964e493936858',1,'dxfcpp::DXEndpoint']]],
  ['connecting_8',['CONNECTING',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#af82eb2c48281dedb4d2a1994f07a22c6a9a14f95e151eec641316e7c784ce832d',1,'dxfcpp::DXEndpoint']]],
  ['containseventtype_9',['containsEventType',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#aca0ef67ba62822be7cbedfc8cab5680a',1,'dxfcpp::DXFeedSubscription']]],
  ['correction_10',['CORRECTION',['../dd/d00/structdxfcpp_1_1_time_and_sale_type.html#a7e2c0901dc3dd99de9dc03dc3e56e933',1,'dxfcpp::TimeAndSaleType']]],
  ['cpu_5ffeature_5fcheck_5ffailed_11',['CPU_FEATURE_CHECK_FAILED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#abb1021d4b2abd795435253c890beb2cd',1,'dxfcpp::CEntryPointErrors']]],
  ['create_12',['create',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a4933409731472ca5aa39d0c83d542428',1,'dxfcpp::DXEndpoint::create()'],['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a230f7841ff2da5b2da3d6d72bd5fb8a0',1,'dxfcpp::DXEndpoint::create(Role role)'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a49b2bc2cb75f94bf9c49920a7cf94286',1,'dxfcpp::DXFeedSubscription::create(const EventTypeEnum &amp;eventType) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#ad29cf904c88e2c175b7dd0c980d36a2b',1,'dxfcpp::DXFeedSubscription::create(EventTypeIt begin, EventTypeIt end) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#accf30348917f797b43ed401bcc521202',1,'dxfcpp::DXFeedSubscription::create(std::initializer_list&lt; EventTypeEnum &gt; eventTypes) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#ac630f6080ba186e6aea9862e1581584f',1,'dxfcpp::DXFeedSubscription::create(EventTypesCollection &amp;&amp;eventTypes) noexcept']]]
];
