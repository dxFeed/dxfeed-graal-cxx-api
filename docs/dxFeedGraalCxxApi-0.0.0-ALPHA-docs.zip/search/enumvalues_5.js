var searchData=
[
  ['on_5fdemand_5ffeed_0',['ON_DEMAND_FEED',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#ac5cd7cd6eed2fdaf9daf96d4e0cf9f2da4e0e3dbd8f06b71f54c84c97fea30e22',1,'dxfcpp::DXEndpoint']]]
];
