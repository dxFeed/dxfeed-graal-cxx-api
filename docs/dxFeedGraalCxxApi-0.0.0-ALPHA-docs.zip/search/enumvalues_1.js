var searchData=
[
  ['dxfc_5fdxendpoint_5frole_5ffeed_0',['DXFC_DXENDPOINT_ROLE_FEED',['../dc/d01/api_8h.html#abe1b604f492f7466688dfeb93c7a4c38a65d674b01bb72aa7126a2aa83518a721',1,'api.h']]],
  ['dxfc_5fdxendpoint_5frole_5flocal_5fhub_1',['DXFC_DXENDPOINT_ROLE_LOCAL_HUB',['../dc/d01/api_8h.html#abe1b604f492f7466688dfeb93c7a4c38a843d3387932748d374b6c28f0784e8c1',1,'api.h']]],
  ['dxfc_5fdxendpoint_5frole_5fon_5fdemand_5ffeed_2',['DXFC_DXENDPOINT_ROLE_ON_DEMAND_FEED',['../dc/d01/api_8h.html#abe1b604f492f7466688dfeb93c7a4c38abdd31f35c6cec00afdb3828031386ba7',1,'api.h']]],
  ['dxfc_5fdxendpoint_5frole_5fpublisher_3',['DXFC_DXENDPOINT_ROLE_PUBLISHER',['../dc/d01/api_8h.html#abe1b604f492f7466688dfeb93c7a4c38a1f2446b6d147c84356a9b27f4bec9eff',1,'api.h']]],
  ['dxfc_5fdxendpoint_5frole_5fstream_5ffeed_4',['DXFC_DXENDPOINT_ROLE_STREAM_FEED',['../dc/d01/api_8h.html#abe1b604f492f7466688dfeb93c7a4c38a4978efb9727556636f1af6eb8fb5edd6',1,'api.h']]],
  ['dxfc_5fdxendpoint_5frole_5fstream_5fpublisher_5',['DXFC_DXENDPOINT_ROLE_STREAM_PUBLISHER',['../dc/d01/api_8h.html#abe1b604f492f7466688dfeb93c7a4c38a7e4eb3b0e4e1a184874d931f1d084ce4',1,'api.h']]],
  ['dxfc_5fdxendpoint_5fstate_5fclosed_6',['DXFC_DXENDPOINT_STATE_CLOSED',['../dc/d01/api_8h.html#a3a7f931ee286a227711ec5dd530323c1a3b1cde06ba459c4718cb9ec8b72531fb',1,'api.h']]],
  ['dxfc_5fdxendpoint_5fstate_5fconnected_7',['DXFC_DXENDPOINT_STATE_CONNECTED',['../dc/d01/api_8h.html#a3a7f931ee286a227711ec5dd530323c1af97d2a4b9a6c3ecfde7ef46735a92f74',1,'api.h']]],
  ['dxfc_5fdxendpoint_5fstate_5fconnecting_8',['DXFC_DXENDPOINT_STATE_CONNECTING',['../dc/d01/api_8h.html#a3a7f931ee286a227711ec5dd530323c1a7be9a33e9adb20ef55995ef0540bd251',1,'api.h']]],
  ['dxfc_5fdxendpoint_5fstate_5fnot_5fconnected_9',['DXFC_DXENDPOINT_STATE_NOT_CONNECTED',['../dc/d01/api_8h.html#a3a7f931ee286a227711ec5dd530323c1a52030993f486cf3c6610c51375383f96',1,'api.h']]],
  ['dxfc_5fec_5ferror_10',['DXFC_EC_ERROR',['../dc/d01/api_8h.html#a6d50a9a293bc5378bd8f9fea7d8db4b2a1cc1fc1901c33f4ee3e652d045e3b2f1',1,'api.h']]],
  ['dxfc_5fec_5fg_5ferr_11',['DXFC_EC_G_ERR',['../dc/d01/api_8h.html#a6d50a9a293bc5378bd8f9fea7d8db4b2a9958980fc36fadb79d45a30c13a4a65a',1,'api.h']]],
  ['dxfc_5fec_5fsuccess_12',['DXFC_EC_SUCCESS',['../dc/d01/api_8h.html#a6d50a9a293bc5378bd8f9fea7d8db4b2a543e126f7c83a9482f5736b16cc675c8',1,'api.h']]]
];
