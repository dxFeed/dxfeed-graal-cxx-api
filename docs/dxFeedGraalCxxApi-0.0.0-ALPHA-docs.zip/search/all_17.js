var searchData=
[
  ['_7ebuilder_0',['~Builder',['../d9/d02/classdxfcpp_1_1_d_x_endpoint_1_1_builder.html#abc9c35e76c8fcc848f7ef3f37f9d7ce4',1,'dxfcpp::DXEndpoint::Builder']]],
  ['_7eentity_1',['~Entity',['../d9/d02/structdxfcpp_1_1_entity.html#a491b6b3c1b6f3ae655ec503e258ce162',1,'dxfcpp::Entity']]]
];
