var searchData=
[
  ['closed_0',['CLOSED',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#af82eb2c48281dedb4d2a1994f07a22c6a110ccf2f5d2ff4eda1fd1a494293467d',1,'dxfcpp::DXEndpoint']]],
  ['connected_1',['CONNECTED',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#af82eb2c48281dedb4d2a1994f07a22c6aa5afd6edd5336d91316964e493936858',1,'dxfcpp::DXEndpoint']]],
  ['connecting_2',['CONNECTING',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#af82eb2c48281dedb4d2a1994f07a22c6a9a14f95e151eec641316e7c784ce832d',1,'dxfcpp::DXEndpoint']]]
];
