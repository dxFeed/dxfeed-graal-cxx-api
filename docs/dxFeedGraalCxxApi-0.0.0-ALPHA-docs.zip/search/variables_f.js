var searchData=
[
  ['threading_5finitialization_5ffailed_0',['THREADING_INITIALIZATION_FAILED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#adc073907d0ad0b0a1af6b7d374e2aadc',1,'dxfcpp::CEntryPointErrors']]],
  ['tx_5fpending_1',['TX_PENDING',['../de/d03/classdxfcpp_1_1_event_flag.html#ae57282251576b5b5a09d93c0b588a3d7',1,'dxfcpp::EventFlag::TX_PENDING'],['../da/d01/structdxfcpp_1_1_indexed_event.html#aa0fa82f8632275341f08649124aa89e3',1,'dxfcpp::IndexedEvent::TX_PENDING']]]
];
