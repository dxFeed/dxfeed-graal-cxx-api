var searchData=
[
  ['zero_0',['ZERO',['../dc/d03/structdxfcpp_1_1_direction.html#a8f35df343051d2ccab48adee22e48e1d',1,'dxfcpp::Direction']]],
  ['zero_5fdown_1',['ZERO_DOWN',['../dc/d03/structdxfcpp_1_1_direction.html#a5c280dcaf9e2d12e6fcdb091c8ec4f9f',1,'dxfcpp::Direction']]],
  ['zero_5fup_2',['ZERO_UP',['../dc/d03/structdxfcpp_1_1_direction.html#a0d9172a737701f90c8c2484dc597bc30',1,'dxfcpp::Direction']]]
];
