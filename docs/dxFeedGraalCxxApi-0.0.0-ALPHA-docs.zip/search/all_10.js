var searchData=
[
  ['read_5faux_5fimage_5fmeta_5ffailed_0',['READ_AUX_IMAGE_META_FAILED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#a3d6f257c44e21c2f23bab2b2dec4116b',1,'dxfcpp::CEntryPointErrors']]],
  ['reconnect_1',['reconnect',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a7ad6212704e2f6a8fbfdb2912342587e',1,'dxfcpp::DXEndpoint']]],
  ['regular_2',['REGULAR',['../d8/d03/structdxfcpp_1_1_price_type.html#a3b8b623b2c7152112d2fb686afa3888e',1,'dxfcpp::PriceType']]],
  ['remove_3',['remove',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#ab2609d65f0497ab0064b08b2c3ace012',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['remove_5fevent_4',['REMOVE_EVENT',['../de/d03/classdxfcpp_1_1_event_flag.html#ae244786e6fb0f520858ac29c08855708',1,'dxfcpp::EventFlag::REMOVE_EVENT'],['../da/d01/structdxfcpp_1_1_indexed_event.html#ae3cd8ed3be94e645913ccd23bfc07edd',1,'dxfcpp::IndexedEvent::REMOVE_EVENT']]],
  ['remove_5fsymbol_5',['REMOVE_SYMBOL',['../de/d03/classdxfcpp_1_1_event_flag.html#a6181d88706e072646fb4594e4fce94ed',1,'dxfcpp::EventFlag']]],
  ['removeeventlistener_6',['removeEventListener',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a25d2c14d02d1435bf2fd3a5f185743e7',1,'dxfcpp::DXFeedSubscription']]],
  ['removestatechangelistener_7',['removeStateChangeListener',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#ae89268e0bca1746a67cb322882535c3a',1,'dxfcpp::DXEndpoint']]],
  ['removesymbols_8',['removeSymbols',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a0a6c47a625a2aa6898abe2813374bde3',1,'dxfcpp::DXFeedSubscription::removeSymbols(const SymbolWrapper &amp;symbolWrapper) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#aec36548fbcdc2b1368a9ebf8ea2f6f6e',1,'dxfcpp::DXFeedSubscription::removeSymbols(SymbolIt begin, SymbolIt end) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#adeb06fb1c486c9828903a577144786ec',1,'dxfcpp::DXFeedSubscription::removeSymbols(SymbolsCollection &amp;&amp;collection) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#ade44b5617d66e7eda5863ba9fe2b03e9',1,'dxfcpp::DXFeedSubscription::removeSymbols(std::initializer_list&lt; SymbolWrapper &gt; collection) noexcept']]],
  ['reserve_5faddress_5fspace_5ffailed_9',['RESERVE_ADDRESS_SPACE_FAILED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#abd0b640e1af379be55cec1e541898f37',1,'dxfcpp::CEntryPointErrors']]],
  ['role_10',['Role',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#ac5cd7cd6eed2fdaf9daf96d4e0cf9f2d',1,'dxfcpp::DXEndpoint']]]
];
