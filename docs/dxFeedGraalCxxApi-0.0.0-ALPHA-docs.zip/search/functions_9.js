var searchData=
[
  ['name_0',['name',['../d2/d01/classdxfcpp_1_1_indexed_event_source.html#a60876eb77d249937307e31a13d6d8bf2',1,'dxfcpp::IndexedEventSource']]],
  ['newbuilder_1',['newBuilder',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a4fd9e984ae1cc206b6ccf9e7d528af29',1,'dxfcpp::DXEndpoint']]]
];
