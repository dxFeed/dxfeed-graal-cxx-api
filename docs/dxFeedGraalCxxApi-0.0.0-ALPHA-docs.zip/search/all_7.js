var searchData=
[
  ['halted_0',['HALTED',['../d9/d02/structdxfcpp_1_1_trading_status.html#adcba73e3144f9bb59c340b5068c7d68a',1,'dxfcpp::TradingStatus']]],
  ['handle_1',['handle',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#a8c2a68abe0e1f45debdaebdf1daa4526',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['handler_2',['Handler',['../da/d01/structdxfcpp_1_1_handler.html',1,'dxfcpp::Handler&lt; Signature &gt;'],['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#a87885dc50d9319b4035ede17eb17ac3c',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;::Handler()']]],
  ['handler_3c_20void_28argtypes_2e_2e_2e_29_3e_3',['Handler&lt; void(ArgTypes...)&gt;',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html',1,'dxfcpp']]],
  ['handler_3c_20void_28const_20std_3a_3avector_3c_20std_3a_3ashared_5fptr_3c_20dxfcpp_3a_3aeventtype_20_3e_20_3e_20_26_29_3e_4',['Handler&lt; void(const std::vector&lt; std::shared_ptr&lt; dxfcpp::EventType &gt; &gt; &amp;)&gt;',['../da/d01/structdxfcpp_1_1_handler.html',1,'dxfcpp']]],
  ['handler_3c_20void_28state_2c_20state_29_3e_5',['Handler&lt; void(State, State)&gt;',['../da/d01/structdxfcpp_1_1_handler.html',1,'dxfcpp']]]
];
