var searchData=
[
  ['dxfc_5fdxendpoint_5frole_5ft_0',['dxfc_dxendpoint_role_t',['../dc/d01/api_8h.html#abe1b604f492f7466688dfeb93c7a4c38',1,'api.h']]],
  ['dxfc_5fdxendpoint_5fstate_5ft_1',['dxfc_dxendpoint_state_t',['../dc/d01/api_8h.html#a3a7f931ee286a227711ec5dd530323c1',1,'api.h']]],
  ['dxfc_5ferror_5fcode_5ft_2',['dxfc_error_code_t',['../dc/d01/api_8h.html#a6d50a9a293bc5378bd8f9fea7d8db4b2',1,'api.h']]]
];
