var searchData=
[
  ['quote_0',['Quote',['../df/d03/classdxfcpp_1_1_quote.html',1,'dxfcpp::Quote'],['../df/d03/classdxfcpp_1_1_quote.html#a19a1eec7c4dc03300771ce15da23a17d',1,'dxfcpp::Quote::Quote() noexcept=default'],['../df/d03/classdxfcpp_1_1_quote.html#aafab284549a0d091da0e12a91d87caa2',1,'dxfcpp::Quote::Quote(std::string eventSymbol) noexcept']]]
];
