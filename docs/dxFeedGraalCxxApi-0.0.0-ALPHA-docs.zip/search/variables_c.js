var searchData=
[
  ['preliminary_0',['PRELIMINARY',['../d8/d03/structdxfcpp_1_1_price_type.html#a6c3ceac783d44449248884e13703ec72',1,'dxfcpp::PriceType']]],
  ['protect_5fheap_5ffailed_1',['PROTECT_HEAP_FAILED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#a694f24336e4806bef18f2449133bb01e',1,'dxfcpp::CEntryPointErrors']]]
];
