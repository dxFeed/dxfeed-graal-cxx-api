var searchData=
[
  ['add_0',['add',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#a845abea0f4f416a3f33130153edf9f7e',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['addeventlistener_1',['addEventListener',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a3cbf630dbc54ce3be50412392102f993',1,'dxfcpp::DXFeedSubscription::addEventListener(EventListener &amp;&amp;listener) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a5d47c3bf1b10e850ea9291522602d7dd',1,'dxfcpp::DXFeedSubscription::addEventListener(std::function&lt; void(const std::vector&lt; std::shared_ptr&lt; EventT &gt; &gt; &amp;)&gt; &amp;&amp;listener) noexcept']]],
  ['addlowpriority_2',['addLowPriority',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#a92d291de6b5347bc519ceb457a797462',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['addstatechangelistener_3',['addStateChangeListener',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a619cb80fb1de10040705be2ce9a20068',1,'dxfcpp::DXEndpoint']]],
  ['addsymbols_4',['addSymbols',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a82f6161c934193091349eacbcf368d26',1,'dxfcpp::DXFeedSubscription::addSymbols(const SymbolWrapper &amp;symbolWrapper) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a1a729f7d17b344447bd15757ffc12a98',1,'dxfcpp::DXFeedSubscription::addSymbols(SymbolIt begin, SymbolIt end) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a8200b1eb47a022ac2c2d64584b61699f',1,'dxfcpp::DXFeedSubscription::addSymbols(const SymbolsCollection &amp;collection) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a20c328d64bbd6ce84210a1394433a8f2',1,'dxfcpp::DXFeedSubscription::addSymbols(std::initializer_list&lt; SymbolWrapper &gt; collection) noexcept']]],
  ['asstringsymbol_5',['asStringSymbol',['../db/d03/structdxfcpp_1_1_symbol_wrapper.html#a9ed87465e80386fc45dcd1ffc3c5b6a6',1,'dxfcpp::SymbolWrapper']]],
  ['aswildcardsymbol_6',['asWildcardSymbol',['../db/d03/structdxfcpp_1_1_symbol_wrapper.html#a8fc8e32454a3c5b4a27271ab719ed571',1,'dxfcpp::SymbolWrapper']]],
  ['attach_7',['attach',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#ab022c88abb0ac4c2090da5e85bdebd34',1,'dxfcpp::DXFeedSubscription']]],
  ['awaitnotconnected_8',['awaitNotConnected',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a82ec4a2efd7f8c976cd3874a31aaacb8',1,'dxfcpp::DXEndpoint']]],
  ['awaitprocessed_9',['awaitProcessed',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a1facf9c56758e1dee75b278d9271ef62',1,'dxfcpp::DXEndpoint']]]
];
