var searchData=
[
  ['open_5faux_5fimage_5ffailed_0',['OPEN_AUX_IMAGE_FAILED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#a4115a25d9683dc92224a6cc63a33e4b8',1,'dxfcpp::CEntryPointErrors']]],
  ['open_5fimage_5ffailed_1',['OPEN_IMAGE_FAILED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#ae227a97e9315f8a1f4bf66b85ef94da8',1,'dxfcpp::CEntryPointErrors']]]
];
