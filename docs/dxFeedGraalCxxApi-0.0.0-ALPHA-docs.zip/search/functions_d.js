var searchData=
[
  ['reconnect_0',['reconnect',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a7ad6212704e2f6a8fbfdb2912342587e',1,'dxfcpp::DXEndpoint']]],
  ['remove_1',['remove',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#ab2609d65f0497ab0064b08b2c3ace012',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['removeeventlistener_2',['removeEventListener',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a25d2c14d02d1435bf2fd3a5f185743e7',1,'dxfcpp::DXFeedSubscription']]],
  ['removestatechangelistener_3',['removeStateChangeListener',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#ae89268e0bca1746a67cb322882535c3a',1,'dxfcpp::DXEndpoint']]],
  ['removesymbols_4',['removeSymbols',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a0a6c47a625a2aa6898abe2813374bde3',1,'dxfcpp::DXFeedSubscription::removeSymbols(const SymbolWrapper &amp;symbolWrapper) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#aec36548fbcdc2b1368a9ebf8ea2f6f6e',1,'dxfcpp::DXFeedSubscription::removeSymbols(SymbolIt begin, SymbolIt end) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#adeb06fb1c486c9828903a577144786ec',1,'dxfcpp::DXFeedSubscription::removeSymbols(SymbolsCollection &amp;&amp;collection) noexcept'],['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#ade44b5617d66e7eda5863ba9fe2b03e9',1,'dxfcpp::DXFeedSubscription::removeSymbols(std::initializer_list&lt; SymbolWrapper &gt; collection) noexcept']]]
];
