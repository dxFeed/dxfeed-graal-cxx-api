var searchData=
[
  ['handle_0',['handle',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#a8c2a68abe0e1f45debdaebdf1daa4526',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['handler_1',['Handler',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#a87885dc50d9319b4035ede17eb17ac3c',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]]
];
