var searchData=
[
  ['inactive_0',['INACTIVE',['../da/d02/structdxfcpp_1_1_short_sale_restriction.html#abfecd1c4b4c3e62fb8da97ec10d9c4ea',1,'dxfcpp::ShortSaleRestriction']]],
  ['indicative_1',['INDICATIVE',['../d8/d03/structdxfcpp_1_1_price_type.html#a2317da2d1576d28678b89db492609b84',1,'dxfcpp::PriceType']]],
  ['insufficient_5faddress_5fspace_2',['INSUFFICIENT_ADDRESS_SPACE',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#a08daf13d4d342f499df866c9b365e9fd',1,'dxfcpp::CEntryPointErrors']]],
  ['insufficient_5faux_5fimage_5fmemory_3',['INSUFFICIENT_AUX_IMAGE_MEMORY',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#aec6096e62222b65058b17485a4364793',1,'dxfcpp::CEntryPointErrors']]],
  ['isolate_5finitialization_5ffailed_4',['ISOLATE_INITIALIZATION_FAILED',['../d5/d01/structdxfcpp_1_1_c_entry_point_errors.html#a303dee0aac5f56b0daeee6b37b1ba30b',1,'dxfcpp::CEntryPointErrors']]]
];
