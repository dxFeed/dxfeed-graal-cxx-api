var searchData=
[
  ['onevent_0',['onEvent',['../d9/d03/classdxfcpp_1_1_d_x_feed_subscription.html#a041f81a28b078ca11aca1b11be0ecc2c',1,'dxfcpp::DXFeedSubscription']]],
  ['onstatechange_1',['onStateChange',['../d0/d03/structdxfcpp_1_1_d_x_endpoint.html#a85142bbe29a101b1f0b2fa39d0c174d0',1,'dxfcpp::DXEndpoint']]],
  ['operator_25_3d_2',['operator%=',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#af6c01a862fc80facca52d320bf9cc1af',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['operator_28_29_3',['operator()',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#aa5d26e4d6181cc1fb70de843a9f471cf',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['operator_2b_3d_4',['operator+=',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#a4f7397739f26b1f78a2d86be9f8f5211',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['operator_2d_3d_5',['operator-=',['../d4/d00/structdxfcpp_1_1_handler_3_01void_07_arg_types_8_8_8_08_4.html#a3fa94d4cd2deb830bca670389843a178',1,'dxfcpp::Handler&lt; void(ArgTypes...)&gt;']]],
  ['optionsale_6',['OptionSale',['../de/d02/classdxfcpp_1_1_option_sale.html#a7f9e70835c82a90dca2427326bf7b924',1,'dxfcpp::OptionSale::OptionSale() noexcept=default'],['../de/d02/classdxfcpp_1_1_option_sale.html#a2ba24b6d87ad9dfd3a757da3bc3ab336',1,'dxfcpp::OptionSale::OptionSale(std::string eventSymbol) noexcept']]]
];
