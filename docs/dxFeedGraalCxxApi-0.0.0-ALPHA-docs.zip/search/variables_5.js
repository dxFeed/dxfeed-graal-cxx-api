var searchData=
[
  ['halted_0',['HALTED',['../d9/d02/structdxfcpp_1_1_trading_status.html#adcba73e3144f9bb59c340b5068c7d68a',1,'dxfcpp::TradingStatus']]]
];
